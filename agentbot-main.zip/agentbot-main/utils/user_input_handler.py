def get_user_input():
    print("Please enter your problem or query:")
    return input()