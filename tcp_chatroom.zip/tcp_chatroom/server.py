#!/usr/bin/env python3
"""
TCP Chat Room Server
Handles multiple clients using threading and socket programming.
"""

import socket
import threading
import json
import time
import sys
from datetime import datetime


HOST = '127.0.0.1'
PORT = 9999
MAX_CLIENTS = 50
BUFFER_SIZE = 4096

clients = {}       # {conn: {"username": str, "color": str, "joined": float}}
clients_lock = threading.Lock()

COLORS = [
    "#00f5ff", "#ff00aa", "#00ff88", "#ffaa00",
    "#aa00ff", "#ff4444", "#44ff44", "#4444ff",
    "#ff8800", "#00ffcc", "#ff0088", "#88ff00",
]
color_index = 0
color_lock = threading.Lock()


def get_next_color():
    global color_index
    with color_lock:
        c = COLORS[color_index % len(COLORS)]
        color_index += 1
    return c


def timestamp():
    return datetime.now().strftime("%H:%M:%S")


def broadcast(message: dict, exclude_conn=None):
    """Send a JSON message to all connected clients."""
    data = (json.dumps(message) + "\n").encode("utf-8")
    with clients_lock:
        dead = []
        for conn in clients:
            if conn == exclude_conn:
                continue
            try:
                conn.sendall(data)
            except Exception:
                dead.append(conn)
        for conn in dead:
            _remove_client(conn)


def send_to(conn, message: dict):
    """Send a JSON message to a single client."""
    try:
        data = (json.dumps(message) + "\n").encode("utf-8")
        conn.sendall(data)
    except Exception:
        pass


def _remove_client(conn):
    """Remove client from registry (must hold clients_lock or call carefully)."""
    if conn in clients:
        info = clients.pop(conn)
        return info
    return None


def get_user_list():
    with clients_lock:
        return [
            {"username": v["username"], "color": v["color"]}
            for v in clients.values()
        ]


def handle_client(conn, addr):
    """Thread target: handle one client connection."""
    print(f"[+] Connection from {addr}")
    username = None
    color = get_next_color()

    # Receive username handshake
    try:
        raw = b""
        while b"\n" not in raw:
            chunk = conn.recv(BUFFER_SIZE)
            if not chunk:
                conn.close()
                return
            raw += chunk
        handshake = json.loads(raw.split(b"\n")[0].decode("utf-8"))
        username = handshake.get("username", f"User_{addr[1]}")[:20]
    except Exception as e:
        print(f"[-] Handshake failed from {addr}: {e}")
        conn.close()
        return

    # Register client
    with clients_lock:
        # Check duplicate username
        existing = [v["username"].lower() for v in clients.values()]
        base = username
        suffix = 1
        while username.lower() in existing:
            username = f"{base}_{suffix}"
            suffix += 1
        clients[conn] = {"username": username, "color": color, "joined": time.time()}

    print(f"[+] {username} joined from {addr}")

    # Send welcome packet to the new user
    send_to(conn, {
        "type": "welcome",
        "username": username,
        "color": color,
        "server_time": timestamp(),
        "users": get_user_list(),
        "message": f"Welcome to TCP ChatRoom, {username}!"
    })

    # Announce join to everyone else
    broadcast({
        "type": "join",
        "username": username,
        "color": color,
        "time": timestamp(),
        "users": get_user_list(),
        "message": f"{username} has entered the chat room"
    }, exclude_conn=conn)

    # Main receive loop
    buffer = b""
    try:
        while True:
            chunk = conn.recv(BUFFER_SIZE)
            if not chunk:
                break
            buffer += chunk
            while b"\n" in buffer:
                line, buffer = buffer.split(b"\n", 1)
                if not line.strip():
                    continue
                try:
                    msg = json.loads(line.decode("utf-8"))
                    handle_message(conn, username, color, msg)
                except json.JSONDecodeError:
                    pass
    except Exception as e:
        print(f"[-] Error with {username}: {e}")
    finally:
        with clients_lock:
            _remove_client(conn)
        conn.close()
        print(f"[-] {username} disconnected")
        broadcast({
            "type": "leave",
            "username": username,
            "color": color,
            "time": timestamp(),
            "users": get_user_list(),
            "message": f"{username} has left the chat room"
        })


def handle_message(conn, username, color, msg):
    """Route incoming message by type."""
    msg_type = msg.get("type", "chat")

    if msg_type == "chat":
        text = msg.get("text", "").strip()[:500]
        if not text:
            return
        print(f"[MSG] {username}: {text}")
        broadcast({
            "type": "chat",
            "username": username,
            "color": color,
            "text": text,
            "time": timestamp(),
        })

    elif msg_type == "ping":
        send_to(conn, {"type": "pong", "time": timestamp()})

    elif msg_type == "userlist":
        send_to(conn, {"type": "userlist", "users": get_user_list()})

    elif msg_type == "dm":
        target = msg.get("target", "")
        text = msg.get("text", "").strip()[:500]
        with clients_lock:
            target_conn = next(
                (c for c, v in clients.items() if v["username"] == target), None
            )
        if target_conn:
            send_to(target_conn, {
                "type": "dm",
                "from": username,
                "color": color,
                "text": text,
                "time": timestamp(),
            })
            send_to(conn, {
                "type": "dm_sent",
                "to": target,
                "text": text,
                "time": timestamp(),
            })
        else:
            send_to(conn, {
                "type": "error",
                "message": f"User '{target}' not found."
            })


def start_server():
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind((HOST, PORT))
    server.listen(MAX_CLIENTS)
    print(f"[SERVER] TCP ChatRoom server listening on {HOST}:{PORT}")
    print(f"[SERVER] Max clients: {MAX_CLIENTS}")
    print("[SERVER] Press Ctrl+C to stop\n")

    try:
        while True:
            conn, addr = server.accept()
            thread = threading.Thread(target=handle_client, args=(conn, addr), daemon=True)
            thread.start()
            with clients_lock:
                print(f"[SERVER] Active connections: {len(clients) + 1}")
    except KeyboardInterrupt:
        print("\n[SERVER] Shutting down...")
    finally:
        broadcast({"type": "server_shutdown", "message": "Server is shutting down."})
        server.close()


if __name__ == "__main__":
    start_server()
