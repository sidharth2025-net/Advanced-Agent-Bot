#!/usr/bin/env python3
"""
TCP ChatRoom Launcher
Starts both the TCP chat server and the web bridge server.
"""

import subprocess
import sys
import time
import os
import threading
import webbrowser

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

def run_process(name, script):
    print(f"[LAUNCH] Starting {name}...")
    proc = subprocess.Popen(
        [sys.executable, script],
        cwd=BASE_DIR,
        stdout=sys.stdout,
        stderr=sys.stderr,
    )
    return proc

def main():
    print("""
╔════════════════════════════════════════════╗
║   QUANTUM NEXUS — TCP CHAT ROOM LAUNCHER   ║
╚════════════════════════════════════════════╝
""")
    # Start TCP server
    server_proc = run_process("TCP Chat Server", os.path.join(BASE_DIR, "server.py"))
    time.sleep(0.8)

    # Start web bridge
    bridge_proc = run_process("Web Bridge", os.path.join(BASE_DIR, "web_bridge.py"))
    time.sleep(1.0)

    print("\n[LAUNCH] ✓ All systems online!")
    print("[LAUNCH] → Open http://127.0.0.1:8080 in your browser")
    print("[LAUNCH] → Or run: python client.py  for terminal access")
    print("[LAUNCH] → Press Ctrl+C to stop all servers\n")

    # Open browser automatically
    threading.Timer(1.5, lambda: webbrowser.open("http://127.0.0.1:8080")).start()

    try:
        server_proc.wait()
    except KeyboardInterrupt:
        print("\n[LAUNCH] Shutting down all processes...")
        for proc in [server_proc, bridge_proc]:
            try:
                proc.terminate()
                proc.wait(timeout=3)
            except Exception:
                proc.kill()
        print("[LAUNCH] All processes stopped.")

if __name__ == "__main__":
    main()
