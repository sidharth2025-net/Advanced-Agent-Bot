#!/usr/bin/env python3
"""
Web Bridge Server
Bridges the browser-based frontend to the TCP chat server using HTTP long-polling.
Run this alongside server.py to enable the web UI.
"""

import json
import threading
import time
import uuid
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
import sys
import os

# Add parent dir so we can import ChatClient
sys.path.insert(0, os.path.dirname(__file__))
from client import ChatClient

TCP_HOST = '127.0.0.1'
TCP_PORT = 9999
WEB_PORT = 8080

# sessions: {session_id: {"client": ChatClient, "queue": list, "lock": Lock}}
sessions = {}
sessions_lock = threading.Lock()

STATIC_DIR = os.path.dirname(os.path.abspath(__file__))


def get_or_create_session(sid):
    with sessions_lock:
        return sessions.get(sid)


def create_session(sid, username):
    client = ChatClient(TCP_HOST, TCP_PORT)
    q = []
    q_lock = threading.Lock()

    def on_msg(msg):
        with q_lock:
            q.append(msg)
        # Trim queue
        with q_lock:
            while len(q) > 200:
                q.pop(0)

    client.on_message = on_msg

    try:
        welcome = client.connect(username)
        on_msg(welcome)
    except Exception as e:
        return None, str(e)

    session = {"client": client, "queue": q, "lock": q_lock, "created": time.time()}
    with sessions_lock:
        sessions[sid] = session
    return session, None


def cleanup_old_sessions():
    """Remove sessions inactive for >10 min."""
    while True:
        time.sleep(60)
        cutoff = time.time() - 600
        with sessions_lock:
            dead = [sid for sid, s in sessions.items()
                    if s.get("created", 0) < cutoff or not s["client"].connected]
        for sid in dead:
            with sessions_lock:
                s = sessions.pop(sid, None)
            if s:
                try:
                    s["client"].disconnect()
                except Exception:
                    pass


threading.Thread(target=cleanup_old_sessions, daemon=True).start()


class BridgeHandler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        pass  # Suppress default logging

    def send_json(self, data, status=200):
        body = json.dumps(data).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def send_file(self, path, content_type):
        try:
            with open(path, "rb") as f:
                body = f.read()
            self.send_response(200)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        except FileNotFoundError:
            self.send_error(404)

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        qs = parse_qs(parsed.query)

        if path == "/" or path == "/index.html":
            self.send_file(os.path.join(STATIC_DIR, "index.html"), "text/html")
            return

        if path == "/api/poll":
            sid = qs.get("sid", [""])[0]
            since = int(qs.get("since", ["0"])[0])
            session = get_or_create_session(sid)
            if not session:
                self.send_json({"error": "session not found"}, 404)
                return
            with session["lock"]:
                msgs = session["queue"][since:]
            self.send_json({"messages": msgs, "total": len(session["queue"]) + since})
            return

        if path == "/api/users":
            sid = qs.get("sid", [""])[0]
            session = get_or_create_session(sid)
            if not session:
                self.send_json({"error": "session not found"}, 404)
                return
            session["client"].request_userlist()
            self.send_json({"ok": True})
            return

        self.send_error(404)

    def do_POST(self):
        parsed = urlparse(self.path)
        path = parsed.path
        length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(length)
        try:
            data = json.loads(body)
        except Exception:
            self.send_json({"error": "invalid JSON"}, 400)
            return

        if path == "/api/connect":
            username = data.get("username", "").strip()[:20]
            if not username:
                self.send_json({"error": "username required"}, 400)
                return
            sid = str(uuid.uuid4())
            session, err = create_session(sid, username)
            if err:
                self.send_json({"error": err}, 500)
                return
            self.send_json({
                "sid": sid,
                "username": session["client"].username,
                "color": session["client"].color,
            })
            return

        if path == "/api/send":
            sid = data.get("sid", "")
            session = get_or_create_session(sid)
            if not session:
                self.send_json({"error": "session not found"}, 404)
                return
            msg_type = data.get("type", "chat")
            try:
                if msg_type == "chat":
                    session["client"].send_chat(data.get("text", ""))
                elif msg_type == "dm":
                    session["client"].send_dm(data.get("target", ""), data.get("text", ""))
            except Exception as e:
                self.send_json({"error": str(e)}, 500)
                return
            self.send_json({"ok": True})
            return

        if path == "/api/disconnect":
            sid = data.get("sid", "")
            with sessions_lock:
                session = sessions.pop(sid, None)
            if session:
                session["client"].disconnect()
            self.send_json({"ok": True})
            return

        self.send_error(404)


def start_web_server():
    server = HTTPServer(("0.0.0.0", WEB_PORT), BridgeHandler)
    print(f"[WEB] Bridge server running at http://127.0.0.1:{WEB_PORT}")
    print(f"[WEB] Open http://127.0.0.1:{WEB_PORT} in your browser\n")
    server.serve_forever()


if __name__ == "__main__":
    start_web_server()
