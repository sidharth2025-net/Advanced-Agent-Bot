#!/usr/bin/env python3
"""
TCP Chat Room Client
Command-line client for connecting to the TCP chat server.
"""

import socket
import threading
import json
import sys
import time
from datetime import datetime


HOST = '127.0.0.1'
PORT = 9999
BUFFER_SIZE = 4096


class ChatClient:
    def __init__(self, host=HOST, port=PORT):
        self.host = host
        self.port = port
        self.sock = None
        self.username = None
        self.color = None
        self.connected = False
        self.on_message = None   # callback(msg_dict)
        self._buffer = b""
        self._recv_thread = None

    def connect(self, username: str) -> dict:
        """Connect to server and perform handshake. Returns welcome packet."""
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.connect((self.host, self.port))
        self.username = username

        # Send handshake
        handshake = json.dumps({"username": username}) + "\n"
        self.sock.sendall(handshake.encode("utf-8"))

        # Wait for welcome packet
        raw = b""
        while b"\n" not in raw:
            chunk = self.sock.recv(BUFFER_SIZE)
            if not chunk:
                raise ConnectionError("Server closed connection during handshake.")
            raw += chunk

        line, remainder = raw.split(b"\n", 1)
        self._buffer = remainder
        welcome = json.loads(line.decode("utf-8"))

        if welcome.get("type") == "welcome":
            self.username = welcome.get("username", username)
            self.color = welcome.get("color", "#ffffff")
            self.connected = True
            self._start_receiver()
            return welcome
        else:
            raise ConnectionError(f"Unexpected server response: {welcome}")

    def _start_receiver(self):
        self._recv_thread = threading.Thread(target=self._receive_loop, daemon=True)
        self._recv_thread.start()

    def _receive_loop(self):
        try:
            while self.connected:
                chunk = self.sock.recv(BUFFER_SIZE)
                if not chunk:
                    self.connected = False
                    if self.on_message:
                        self.on_message({"type": "disconnected", "message": "Connection to server lost."})
                    break
                self._buffer += chunk
                while b"\n" in self._buffer:
                    line, self._buffer = self._buffer.split(b"\n", 1)
                    if not line.strip():
                        continue
                    try:
                        msg = json.loads(line.decode("utf-8"))
                        if self.on_message:
                            self.on_message(msg)
                    except json.JSONDecodeError:
                        pass
        except Exception as e:
            self.connected = False
            if self.on_message:
                self.on_message({"type": "error", "message": str(e)})

    def send(self, msg: dict):
        """Send a JSON message to the server."""
        if not self.connected:
            raise ConnectionError("Not connected.")
        data = (json.dumps(msg) + "\n").encode("utf-8")
        self.sock.sendall(data)

    def send_chat(self, text: str):
        self.send({"type": "chat", "text": text})

    def send_dm(self, target: str, text: str):
        self.send({"type": "dm", "target": target, "text": text})

    def request_userlist(self):
        self.send({"type": "userlist"})

    def ping(self):
        self.send({"type": "ping"})

    def disconnect(self):
        self.connected = False
        try:
            self.sock.close()
        except Exception:
            pass


# ─── Terminal UI ─────────────────────────────────────────────────────────────

def clear_line():
    sys.stdout.write("\r\033[K")
    sys.stdout.flush()

def print_msg(text, end="\n"):
    clear_line()
    print(text, end=end)
    sys.stdout.write("> ")
    sys.stdout.flush()

ANSI_RESET = "\033[0m"

def hex_to_ansi(hex_color: str) -> str:
    hex_color = hex_color.lstrip("#")
    r, g, b = int(hex_color[0:2],16), int(hex_color[2:4],16), int(hex_color[4:6],16)
    return f"\033[38;2;{r};{g};{b}m"


def run_terminal_client():
    print("\n╔══════════════════════════════════╗")
    print("║    TCP CHAT ROOM — TERMINAL      ║")
    print("╚══════════════════════════════════╝\n")

    username = input("Enter your username: ").strip()
    if not username:
        print("Username cannot be empty.")
        return

    host = input(f"Server host [{HOST}]: ").strip() or HOST
    port_str = input(f"Server port [{PORT}]: ").strip()
    port = int(port_str) if port_str.isdigit() else PORT

    client = ChatClient(host, port)

    def on_message(msg):
        t = msg.get("time", "")
        mtype = msg.get("type", "")
        if mtype == "chat":
            color = hex_to_ansi(msg.get("color", "#ffffff"))
            print_msg(f"[{t}] {color}{msg['username']}{ANSI_RESET}: {msg['text']}")
        elif mtype in ("join", "leave"):
            color = hex_to_ansi(msg.get("color", "#888888"))
            print_msg(f"[{t}] *** {color}{msg['message']}{ANSI_RESET}")
        elif mtype == "dm":
            color = hex_to_ansi(msg.get("color", "#ffaa00"))
            print_msg(f"[{t}] [DM from {color}{msg['from']}{ANSI_RESET}]: {msg['text']}")
        elif mtype == "dm_sent":
            print_msg(f"[{t}] [DM to {msg['to']}]: {msg['text']}")
        elif mtype == "server_shutdown":
            print_msg(f"\n[SERVER] {msg.get('message','Server shut down.')}")
        elif mtype == "error":
            print_msg(f"[ERROR] {msg.get('message','')}")
        elif mtype == "disconnected":
            print_msg(f"\n[DISCONNECTED] {msg.get('message','')}")
        elif mtype == "pong":
            print_msg(f"[PONG] Server time: {t}")
        elif mtype == "userlist":
            users = msg.get("users", [])
            print_msg("[USERS] " + ", ".join(u["username"] for u in users))

    client.on_message = on_message

    try:
        welcome = client.connect(username)
        print(f"\n{welcome.get('message','Connected!')}")
        users = welcome.get("users", [])
        if users:
            names = ", ".join(u["username"] for u in users)
            print(f"Online: {names}")
        print("\nCommands: /dm <user> <message>  /users  /ping  /quit\n")
    except Exception as e:
        print(f"Connection failed: {e}")
        return

    try:
        while client.connected:
            sys.stdout.write("> ")
            sys.stdout.flush()
            line = sys.stdin.readline()
            if not line:
                break
            text = line.strip()
            if not text:
                continue
            if text == "/quit":
                break
            elif text == "/users":
                client.request_userlist()
            elif text == "/ping":
                client.ping()
            elif text.startswith("/dm "):
                parts = text[4:].split(" ", 1)
                if len(parts) == 2:
                    client.send_dm(parts[0], parts[1])
                else:
                    clear_line()
                    print("Usage: /dm <username> <message>")
            else:
                client.send_chat(text)
    except KeyboardInterrupt:
        pass
    finally:
        print("\nDisconnecting...")
        client.disconnect()


if __name__ == "__main__":
    run_terminal_client()
