# ⬡ QUANTUM NEXUS — TCP Chat Room

A full-stack multi-client TCP chat application with a stunning 3D cyberpunk web UI and Python backend.

---

## 🗂 Project Structure

```
tcp_chatroom/
├── server.py        — TCP Chat Server (core backend)
├── client.py        — Terminal CLI Client
├── web_bridge.py    — HTTP Bridge (connects browser ↔ TCP server)
├── index.html       — 3D Web Frontend (open in browser)
├── launch.py        — One-click launcher (starts everything)
└── README.md
```

---

## 🚀 Quick Start

### Option 1 — One-Click Launch (recommended)
```bash
python launch.py
```
Opens the browser automatically at http://127.0.0.1:8080

---

### Option 2 — Manual Start

**Terminal 1 — Start TCP Server:**
```bash
python server.py
```

**Terminal 2 — Start Web Bridge:**
```bash
python web_bridge.py
```

**Then open:** http://127.0.0.1:8080

---

### Option 3 — Terminal Client Only
```bash
# Make sure server.py is running first
python client.py
```

---

## 💬 Features

| Feature | Description |
|---|---|
| Multi-client | Up to 50 simultaneous connections |
| Public chat | Broadcast messages to all users |
| Direct messages | `/dm <user> <message>` or DM panel in UI |
| User presence | Live online user list with color avatars |
| System events | Join/leave notifications |
| 3D UI | Animated starfield, floating hexagons, perspective grid |

---

## 🖥 Architecture

```
Browser (index.html)
       ↕  HTTP polling (port 8080)
  web_bridge.py
       ↕  TCP socket (port 9999)
    server.py
       ↕  TCP sockets
  Multiple client.py instances
```

The web bridge translates HTTP requests from the browser into TCP messages to the chat server, allowing the browser-based 3D UI to work with the raw TCP socket backend.

---

## 🎮 UI Controls

- **Type + Enter** — Send message
- **Shift+Enter** — New line in message
- **Click username** in sidebar → sets DM target
- **DM field** — Type a username to send direct messages
- **◼ EXIT** — Disconnect

---

## ⚙️ Configuration

Edit the top of each file to change defaults:

| File | Setting | Default |
|---|---|---|
| `server.py` | `HOST`, `PORT` | 127.0.0.1, 9999 |
| `web_bridge.py` | `TCP_PORT`, `WEB_PORT` | 9999, 8080 |
| `client.py` | `HOST`, `PORT` | 127.0.0.1, 9999 |

---

## 📦 Requirements

- Python 3.8+
- No external packages required (stdlib only)
